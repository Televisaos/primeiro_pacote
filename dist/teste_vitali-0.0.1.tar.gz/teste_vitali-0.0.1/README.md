# pacote_teste_vitali

Description
The package pacote_teste_vitali is only for training package creation by the autor without any other purpose or function :-p

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable) to install package_name

```bash
pip install pacote_teste_vitali
```

## Usage

```python
from pacote_teste_vitali.module1_name import file1_name
file1_name.my_function()
```

## Author
Tiago Vitali

## License
[MIT](https://choosealicense.com/licenses/mit/)